#先来更新一下包管理库
sudo apt update

#添加一下docker的包仓库的依赖文件
sudo apt install apt-transport-https ca-certificates curl gnupg-agent software-properties-common

#添加仓库钥匙
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -

#把在线仓库连接加到你的更新源里
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"

#默认安装最新版docker
sudo apt update
sudo apt install docker-ce docker-ce-cli containerd.io -y

sudo systemctl status docker

curl -sL https://raw.githubusercontent.com/huan/docker-wechat/master/dochat.sh | bash

sudo usermod -aG docker $USER
