# 参考链接：
# [git bash安装tmux实现多标签](https://www.jianshu.com/p/2defec71e2de)

git clone https://hub.nuaa.cf/xnng/bash.git
cd bash
cp tmux/bin/* /usr/bin
cp tmux/share/* /usr/share -r

echo "setw -g mouse
set-option -g history-limit 20000
set-option -g mouse on
bind -n WheelUpPane select-pane -t= \; copy-mode -e \; send-keys -M
bind -n WheelDownPane select-pane -t= \; send-keys -M
" >  ~/.tmux.conf

