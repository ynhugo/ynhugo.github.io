sudo docker run \
	 --name DoChat \
	 --rm \
	 -i \
	 \
	 -v "$HOME/DoChat/WeChat Files/":'/home/$USER/WeChat Files/' \
	 -v "$HOME/DoChat/Applcation Data":'/home/$USER/.wine/drive_c/users/user/Application Data/' \
	 -v /tmp/.X11-unix:/tmp/.X11-unix \
	 \
	 -e DISPLAY \
	 \
	 -e XMODIFIERS=@im=fcitx \
	 -e GTK_IM_MODULE=fcitx \
	 -e QT_IM_MODULE=fcitx \
	 -e GID="$(id -g)" \
	 -e UID="$(id -u)" \
	 \
	 --ipc=host \
	 --privileged \
	 \
	 zixia/wechat
